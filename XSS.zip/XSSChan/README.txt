# XSS
Test your abilities to hunt an XSS vulnerability
This challenge consists of 10 levels
(easy | medium | hard | Impossible)
Download method:
download the file xss.zip
Extract the file
if you in windows download any host server like: WAMP
if your in linux So this is simple
Extract file in direction /var/www/html
start a server apache2 or any server
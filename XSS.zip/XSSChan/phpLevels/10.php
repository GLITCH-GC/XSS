<body style="background: #121212; color: #fff">
    <style>
        .h2cc{
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
        }
    </style>
    <h1 style="text-align: center; color: red">Your Mission:</h1>
    <code style="display: flex; justify-content: center">
        Your Mission 10 Is to Hunt A Real Bug
    </code>
    <h2 class="h2cc">Good Bay</h2>
</body>

